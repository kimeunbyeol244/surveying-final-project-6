from pathlib import Path
import re, shutil, sys
root = Path(sys.argv[1]) if len(sys.argv)>1 else Path.cwd()
source = Path(__file__).resolve().parent
index = root / 'docs' / 'index.md'
text = index.read_text(encoding='utf-8')
pattern = r'(?ms)^## 6\. 결과[^\n]*\n.*?(?=^## 7\. 토의)'
updated, n = re.subn(pattern, lambda _: (source/'results.md').read_text(encoding='utf-8').rstrip()+'\n\n', text)
if n != 1: raise SystemExit('6장 경계를 정확히 한 번 찾지 못했습니다. 기존 파일은 변경하지 않았습니다.')
backup = index.with_suffix('.md.bak')
if not backup.exists(): shutil.copy2(index, backup)
figs = root/'docs'/'figures'; figs.mkdir(exist_ok=True)
for f in (source/'figures').glob('*.png'): shutil.copy2(f,figs/f.name)
index.write_text(updated,encoding='utf-8')
print('6장 교체 완료:',index,'/ 백업:',backup)
